﻿namespace AppPreview
{
    partial class UserControlSarah
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlSarah));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelLive1 = new System.Windows.Forms.Label();
            this.labelBirth1 = new System.Windows.Forms.Label();
            this.labelWork1 = new System.Windows.Forms.Label();
            this.labelStudy1 = new System.Windows.Forms.Label();
            this.labelName1 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBoxName1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(106, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 41);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 65;
            this.pictureBox1.TabStop = false;
            // 
            // labelLive1
            // 
            this.labelLive1.AutoSize = true;
            this.labelLive1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLive1.Location = new System.Drawing.Point(49, 175);
            this.labelLive1.Name = "labelLive1";
            this.labelLive1.Size = new System.Drawing.Size(57, 16);
            this.labelLive1.TabIndex = 64;
            this.labelLive1.Text = "Lives At : ";
            // 
            // labelBirth1
            // 
            this.labelBirth1.AutoSize = true;
            this.labelBirth1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBirth1.Location = new System.Drawing.Point(49, 147);
            this.labelBirth1.Name = "labelBirth1";
            this.labelBirth1.Size = new System.Drawing.Size(82, 16);
            this.labelBirth1.TabIndex = 63;
            this.labelBirth1.Text = "Date of Birth : ";
            // 
            // labelWork1
            // 
            this.labelWork1.AutoSize = true;
            this.labelWork1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWork1.Location = new System.Drawing.Point(49, 121);
            this.labelWork1.Name = "labelWork1";
            this.labelWork1.Size = new System.Drawing.Size(57, 16);
            this.labelWork1.TabIndex = 62;
            this.labelWork1.Text = "Work At : ";
            // 
            // labelStudy1
            // 
            this.labelStudy1.AutoSize = true;
            this.labelStudy1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStudy1.Location = new System.Drawing.Point(49, 94);
            this.labelStudy1.Name = "labelStudy1";
            this.labelStudy1.Size = new System.Drawing.Size(69, 16);
            this.labelStudy1.TabIndex = 61;
            this.labelStudy1.Text = "Studies At : ";
            // 
            // labelName1
            // 
            this.labelName1.AutoSize = true;
            this.labelName1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName1.Location = new System.Drawing.Point(49, 68);
            this.labelName1.Name = "labelName1";
            this.labelName1.Size = new System.Drawing.Size(69, 16);
            this.labelName1.TabIndex = 60;
            this.labelName1.Text = "Full Name : ";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(174, 173);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(78, 20);
            this.textBox4.TabIndex = 59;
            this.textBox4.Text = "Lahore, Pakistan";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(174, 147);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(78, 20);
            this.textBox3.TabIndex = 58;
            this.textBox3.Text = "6-October";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(174, 121);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(78, 20);
            this.textBox2.TabIndex = 57;
            this.textBox2.Text = "Nill";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(174, 92);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(78, 20);
            this.textBox1.TabIndex = 56;
            this.textBox1.Text = "XYZ institute";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxName1
            // 
            this.textBoxName1.Location = new System.Drawing.Point(174, 66);
            this.textBoxName1.Name = "textBoxName1";
            this.textBoxName1.Size = new System.Drawing.Size(78, 20);
            this.textBoxName1.TabIndex = 55;
            this.textBoxName1.Text = "Sarah Khayyam";
            this.textBoxName1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UserControlSarah
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelLive1);
            this.Controls.Add(this.labelBirth1);
            this.Controls.Add(this.labelWork1);
            this.Controls.Add(this.labelStudy1);
            this.Controls.Add(this.labelName1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBoxName1);
            this.Name = "UserControlSarah";
            this.Size = new System.Drawing.Size(300, 205);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelLive1;
        private System.Windows.Forms.Label labelBirth1;
        private System.Windows.Forms.Label labelWork1;
        private System.Windows.Forms.Label labelStudy1;
        private System.Windows.Forms.Label labelName1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBoxName1;
    }
}
