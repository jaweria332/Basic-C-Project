﻿namespace AppPreview
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonSms = new System.Windows.Forms.Button();
            this.buttonCall = new System.Windows.Forms.Button();
            this.buttonContact = new System.Windows.Forms.Button();
            this.buttonHelp = new System.Windows.Forms.Button();
            this.buttonSetting = new System.Windows.Forms.Button();
            this.panelSlide = new System.Windows.Forms.Panel();
            this.buttonHomepage = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonAli = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonUzma = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonShamza = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonReesha = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonSarah = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.userControl1Ali1 = new AppPreview.UserControl1Ali();
            this.userControlUzma1 = new AppPreview.UserControlUzma();
            this.userControlReesha1 = new AppPreview.UserControlReesha();
            this.userControlShamza1 = new AppPreview.UserControlShamza();
            this.userControlSarah1 = new AppPreview.UserControlSarah();
            this.userControlCentre1 = new AppPreview.UserControlCentre();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panelSlide.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(763, 34);
            this.panel1.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.Location = new System.Drawing.Point(693, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(29, 27);
            this.button8.TabIndex = 8;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "TeamViewer Preview";
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(725, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(29, 27);
            this.button7.TabIndex = 7;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Controls.Add(this.buttonSms);
            this.flowLayoutPanel1.Controls.Add(this.buttonCall);
            this.flowLayoutPanel1.Controls.Add(this.buttonContact);
            this.flowLayoutPanel1.Controls.Add(this.buttonHelp);
            this.flowLayoutPanel1.Controls.Add(this.buttonSetting);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(722, 34);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(41, 392);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 31);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSms
            // 
            this.buttonSms.FlatAppearance.BorderSize = 0;
            this.buttonSms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSms.Image = ((System.Drawing.Image)(resources.GetObject("buttonSms.Image")));
            this.buttonSms.Location = new System.Drawing.Point(3, 40);
            this.buttonSms.Name = "buttonSms";
            this.buttonSms.Size = new System.Drawing.Size(29, 29);
            this.buttonSms.TabIndex = 3;
            this.buttonSms.UseVisualStyleBackColor = true;
            this.buttonSms.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonCall
            // 
            this.buttonCall.FlatAppearance.BorderSize = 0;
            this.buttonCall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCall.Image = ((System.Drawing.Image)(resources.GetObject("buttonCall.Image")));
            this.buttonCall.Location = new System.Drawing.Point(3, 75);
            this.buttonCall.Name = "buttonCall";
            this.buttonCall.Size = new System.Drawing.Size(29, 27);
            this.buttonCall.TabIndex = 3;
            this.buttonCall.UseVisualStyleBackColor = true;
            this.buttonCall.Click += new System.EventHandler(this.buttonCall_Click);
            // 
            // buttonContact
            // 
            this.buttonContact.FlatAppearance.BorderSize = 0;
            this.buttonContact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonContact.Image = ((System.Drawing.Image)(resources.GetObject("buttonContact.Image")));
            this.buttonContact.Location = new System.Drawing.Point(3, 108);
            this.buttonContact.Name = "buttonContact";
            this.buttonContact.Size = new System.Drawing.Size(29, 27);
            this.buttonContact.TabIndex = 4;
            this.buttonContact.UseVisualStyleBackColor = true;
            this.buttonContact.Click += new System.EventHandler(this.buttonContact_Click);
            // 
            // buttonHelp
            // 
            this.buttonHelp.FlatAppearance.BorderSize = 0;
            this.buttonHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHelp.Image = ((System.Drawing.Image)(resources.GetObject("buttonHelp.Image")));
            this.buttonHelp.Location = new System.Drawing.Point(3, 141);
            this.buttonHelp.Name = "buttonHelp";
            this.buttonHelp.Size = new System.Drawing.Size(29, 27);
            this.buttonHelp.TabIndex = 5;
            this.buttonHelp.UseVisualStyleBackColor = true;
            this.buttonHelp.Click += new System.EventHandler(this.buttonHelp_Click);
            // 
            // buttonSetting
            // 
            this.buttonSetting.FlatAppearance.BorderSize = 0;
            this.buttonSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSetting.Image = ((System.Drawing.Image)(resources.GetObject("buttonSetting.Image")));
            this.buttonSetting.Location = new System.Drawing.Point(3, 174);
            this.buttonSetting.Name = "buttonSetting";
            this.buttonSetting.Size = new System.Drawing.Size(29, 27);
            this.buttonSetting.TabIndex = 6;
            this.buttonSetting.UseVisualStyleBackColor = true;
            this.buttonSetting.Click += new System.EventHandler(this.buttonSetting_Click);
            // 
            // panelSlide
            // 
            this.panelSlide.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panelSlide.Controls.Add(this.buttonHomepage);
            this.panelSlide.Controls.Add(this.label14);
            this.panelSlide.Controls.Add(this.label15);
            this.panelSlide.Controls.Add(this.buttonAli);
            this.panelSlide.Controls.Add(this.label12);
            this.panelSlide.Controls.Add(this.label13);
            this.panelSlide.Controls.Add(this.buttonUzma);
            this.panelSlide.Controls.Add(this.label10);
            this.panelSlide.Controls.Add(this.label11);
            this.panelSlide.Controls.Add(this.buttonShamza);
            this.panelSlide.Controls.Add(this.label9);
            this.panelSlide.Controls.Add(this.label8);
            this.panelSlide.Controls.Add(this.buttonReesha);
            this.panelSlide.Controls.Add(this.label7);
            this.panelSlide.Controls.Add(this.label6);
            this.panelSlide.Controls.Add(this.label5);
            this.panelSlide.Controls.Add(this.buttonSarah);
            this.panelSlide.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSlide.Location = new System.Drawing.Point(517, 34);
            this.panelSlide.Name = "panelSlide";
            this.panelSlide.Size = new System.Drawing.Size(205, 392);
            this.panelSlide.TabIndex = 2;
            // 
            // buttonHomepage
            // 
            this.buttonHomepage.BackColor = System.Drawing.Color.Navy;
            this.buttonHomepage.FlatAppearance.BorderSize = 0;
            this.buttonHomepage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHomepage.ForeColor = System.Drawing.Color.White;
            this.buttonHomepage.Location = new System.Drawing.Point(6, 343);
            this.buttonHomepage.Name = "buttonHomepage";
            this.buttonHomepage.Size = new System.Drawing.Size(193, 34);
            this.buttonHomepage.TabIndex = 16;
            this.buttonHomepage.Text = "Go to home page";
            this.buttonHomepage.UseVisualStyleBackColor = false;
            this.buttonHomepage.Click += new System.EventHandler(this.buttonHomepage_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(118, 278);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 16);
            this.label14.TabIndex = 15;
            this.label14.Text = "Active now";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(67, 258);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Ali";
            // 
            // buttonAli
            // 
            this.buttonAli.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAli.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAli.Image = ((System.Drawing.Image)(resources.GetObject("buttonAli.Image")));
            this.buttonAli.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAli.Location = new System.Drawing.Point(6, 254);
            this.buttonAli.Name = "buttonAli";
            this.buttonAli.Size = new System.Drawing.Size(193, 47);
            this.buttonAli.TabIndex = 13;
            this.buttonAli.UseVisualStyleBackColor = true;
            this.buttonAli.Click += new System.EventHandler(this.buttonAli_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label12.Location = new System.Drawing.Point(118, 223);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 16);
            this.label12.TabIndex = 12;
            this.label12.Text = "Active now";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(67, 203);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 20);
            this.label13.TabIndex = 11;
            this.label13.Text = "Uzma khan";
            // 
            // buttonUzma
            // 
            this.buttonUzma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUzma.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUzma.Image = ((System.Drawing.Image)(resources.GetObject("buttonUzma.Image")));
            this.buttonUzma.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonUzma.Location = new System.Drawing.Point(6, 199);
            this.buttonUzma.Name = "buttonUzma";
            this.buttonUzma.Size = new System.Drawing.Size(193, 47);
            this.buttonUzma.TabIndex = 10;
            this.buttonUzma.UseVisualStyleBackColor = true;
            this.buttonUzma.Click += new System.EventHandler(this.buttonUzma_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(118, 170);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Active now";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(67, 150);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 20);
            this.label11.TabIndex = 8;
            this.label11.Text = "Shamza Malik";
            // 
            // buttonShamza
            // 
            this.buttonShamza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonShamza.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShamza.Image = ((System.Drawing.Image)(resources.GetObject("buttonShamza.Image")));
            this.buttonShamza.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonShamza.Location = new System.Drawing.Point(6, 146);
            this.buttonShamza.Name = "buttonShamza";
            this.buttonShamza.Size = new System.Drawing.Size(193, 47);
            this.buttonShamza.TabIndex = 7;
            this.buttonShamza.UseVisualStyleBackColor = true;
            this.buttonShamza.Click += new System.EventHandler(this.buttonShamza_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(118, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 16);
            this.label9.TabIndex = 6;
            this.label9.Text = "Active now";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(67, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 20);
            this.label8.TabIndex = 5;
            this.label8.Text = "Reesha Khan";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // buttonReesha
            // 
            this.buttonReesha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReesha.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReesha.Image = ((System.Drawing.Image)(resources.GetObject("buttonReesha.Image")));
            this.buttonReesha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonReesha.Location = new System.Drawing.Point(6, 93);
            this.buttonReesha.Name = "buttonReesha";
            this.buttonReesha.Size = new System.Drawing.Size(193, 47);
            this.buttonReesha.TabIndex = 4;
            this.buttonReesha.UseVisualStyleBackColor = true;
            this.buttonReesha.Click += new System.EventHandler(this.buttonReesha_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(118, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Active now";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(67, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Sarah Khayyam";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(7, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "See who is active for meeting";
            // 
            // buttonSarah
            // 
            this.buttonSarah.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSarah.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSarah.Image = ((System.Drawing.Image)(resources.GetObject("buttonSarah.Image")));
            this.buttonSarah.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSarah.Location = new System.Drawing.Point(6, 40);
            this.buttonSarah.Name = "buttonSarah";
            this.buttonSarah.Size = new System.Drawing.Size(193, 47);
            this.buttonSarah.TabIndex = 0;
            this.buttonSarah.UseVisualStyleBackColor = true;
            this.buttonSarah.Click += new System.EventHandler(this.buttonSarah_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 30;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // userControl1Ali1
            // 
            this.userControl1Ali1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userControl1Ali1.Location = new System.Drawing.Point(15, 63);
            this.userControl1Ali1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.userControl1Ali1.Name = "userControl1Ali1";
            this.userControl1Ali1.Size = new System.Drawing.Size(477, 328);
            this.userControl1Ali1.TabIndex = 3;
            // 
            // userControlUzma1
            // 
            this.userControlUzma1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userControlUzma1.Location = new System.Drawing.Point(15, 63);
            this.userControlUzma1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.userControlUzma1.Name = "userControlUzma1";
            this.userControlUzma1.Size = new System.Drawing.Size(477, 337);
            this.userControlUzma1.TabIndex = 4;
            // 
            // userControlReesha1
            // 
            this.userControlReesha1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userControlReesha1.Location = new System.Drawing.Point(14, 63);
            this.userControlReesha1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.userControlReesha1.Name = "userControlReesha1";
            this.userControlReesha1.Size = new System.Drawing.Size(478, 337);
            this.userControlReesha1.TabIndex = 5;
            // 
            // userControlShamza1
            // 
            this.userControlShamza1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userControlShamza1.Location = new System.Drawing.Point(15, 63);
            this.userControlShamza1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.userControlShamza1.Name = "userControlShamza1";
            this.userControlShamza1.Size = new System.Drawing.Size(477, 337);
            this.userControlShamza1.TabIndex = 6;
            // 
            // userControlSarah1
            // 
            this.userControlSarah1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userControlSarah1.Location = new System.Drawing.Point(15, 63);
            this.userControlSarah1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.userControlSarah1.Name = "userControlSarah1";
            this.userControlSarah1.Size = new System.Drawing.Size(477, 328);
            this.userControlSarah1.TabIndex = 7;
            // 
            // userControlCentre1
            // 
            this.userControlCentre1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.userControlCentre1.Location = new System.Drawing.Point(14, 45);
            this.userControlCentre1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.userControlCentre1.Name = "userControlCentre1";
            this.userControlCentre1.Size = new System.Drawing.Size(495, 355);
            this.userControlCentre1.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(763, 426);
            this.Controls.Add(this.userControlCentre1);
            this.Controls.Add(this.userControlSarah1);
            this.Controls.Add(this.userControlShamza1);
            this.Controls.Add(this.userControlReesha1);
            this.Controls.Add(this.userControlUzma1);
            this.Controls.Add(this.userControl1Ali1);
            this.Controls.Add(this.panelSlide);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Navy;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panelSlide.ResumeLayout(false);
            this.panelSlide.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panelSlide;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonSms;
        private System.Windows.Forms.Button buttonCall;
        private System.Windows.Forms.Button buttonContact;
        private System.Windows.Forms.Button buttonHelp;
        private System.Windows.Forms.Button buttonSetting;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonSarah;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonAli;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonUzma;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonShamza;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonReesha;
        private System.Windows.Forms.Button buttonHomepage;
        private UserControl1Ali userControl1Ali1;
        private UserControlUzma userControlUzma1;
        private UserControlReesha userControlReesha1;
        private UserControlShamza userControlShamza1;
        private UserControlSarah userControlSarah1;
        private UserControlCentre userControlCentre1;
    }
}

