﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace AppPreview
{
    public partial class Form1 : Form
    {
        int panelWidth;
        bool Hidden;
        public Form1()
        {
            InitializeComponent();
            panelWidth = panelSlide.Width;
            Hidden = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Hidden)
            {
                panelSlide.Width = panelSlide.Width + 10;
                if(panelSlide.Width >= panelWidth)
                {
                    timer1.Stop();
                    Hidden = false;
                    this.Refresh();
                }
            }
            else
            {
                panelSlide.Width = panelSlide.Width - 10;
                if (panelSlide.Width <= 0)
                {
                    timer1.Stop();
                    Hidden = true;
                    this.Refresh();
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void buttonCall_Click(object sender, EventArgs e)
        {
           
        }

        private void buttonContact_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonSetting_Click(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void buttonSarah_Click(object sender, EventArgs e)
        {
            //hiding all other usercontrol
            userControlCentre1.Hide();
            userControlReesha1.Hide();
            userControlShamza1.Hide();
            userControlUzma1.Hide();
            userControl1Ali1.Hide();

            //Showing Sarah user control
            userControlSarah1.Show();
            userControlSarah1.BringToFront();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void buttonReesha_Click(object sender, EventArgs e)
        {
            //hiding all other usercontrol
            userControlCentre1.Hide();
            userControlSarah1.Hide();
            userControlShamza1.Hide();
            userControlUzma1.Hide();
            userControl1Ali1.Hide();

            //Showing Reesha's user control
            userControlReesha1.Show();
            userControlReesha1.BringToFront();
        }

        private void buttonShamza_Click(object sender, EventArgs e)
        {
            //hiding all other usercontrol
            userControlCentre1.Hide();
            userControlReesha1.Hide();
            userControlSarah1.Hide();
            userControlUzma1.Hide();
            userControl1Ali1.Hide();

            //Showing Shamza's user control
            userControlShamza1.Show();
            userControlShamza1.BringToFront();
        }

        private void buttonUzma_Click(object sender, EventArgs e)
        {
            //hiding all other usercontrol
            userControlCentre1.Hide();
            userControlReesha1.Hide();
            userControlShamza1.Hide();
            userControlSarah1.Hide();
            userControl1Ali1.Hide();

            //Showing Uzma's user control
            userControlUzma1.Show();
            userControlUzma1.BringToFront();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void buttonAli_Click(object sender, EventArgs e)
        {
            //hiding all other usercontrol
            userControlCentre1.Hide();
            userControlReesha1.Hide();
            userControlShamza1.Hide();
            userControlUzma1.Hide();
            userControlSarah1.Hide();

            //Showing Ali's user control
            userControl1Ali1.Show();
            userControl1Ali1.BringToFront();
        }

        private void buttonHomepage_Click(object sender, EventArgs e)
        {
            //hiding all other usercontrol
            userControlSarah1.Hide();
            userControlReesha1.Hide();
            userControlShamza1.Hide();
            userControlUzma1.Hide();
            userControl1Ali1.Hide();

            //Showing central user control
            userControlCentre1.Show();
            userControlCentre1.BringToFront();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            userControlCentre1.Hide();
            userControlSarah1.Hide();
            userControlReesha1.Hide();
            userControlShamza1.Hide();
            userControlUzma1.Hide();
            userControl1Ali1.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
