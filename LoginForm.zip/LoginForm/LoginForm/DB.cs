﻿using System;


using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace LoginForm
{
    class DB
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=E:\\C#\\LoginForm\\LoginForm\\LoginInfo.mdf;Integrated Security=True");
        
        //create a function to open the connection to database
        public void OpenConnection()
        {
            if(con.State==System.Data.ConnectionState.Closed)
            {
                con.Open();
            }
        }

        //create a function to close the connection to database
        public void CloseConnection()
        {
            if (con.State == System.Data.ConnectionState.Open)
            {
                con.Close();
            }
        }
        //create a function to return the connection to database
        public SqlConnection GetConnection()
        {
            return con;
        }
    }
}
