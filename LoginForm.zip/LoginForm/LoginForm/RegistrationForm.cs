﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LoginForm
{
    public partial class RegistrationForm : Form
    {
        int auto_id;
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=E:\\C#\\LoginForm\\LoginForm\\LoginInfo.mdf;Integrated Security=True");
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void textFirstname_Click(object sender, EventArgs e)
        {
        
        }
        private void textBoxID_Enter(object sender, EventArgs e)
        {
            string id = textBoxID.Text;
            if (id.Equals("ID"))
            {
                textBoxID.Text = "";
                textBoxID.ForeColor = Color.Black;
            }
        }

        private void textBoxID_Leave(object sender, EventArgs e)
        {
            string id = textBoxID.Text;
            if (id.Equals("ID") || id.Equals(""))
            {
                textBoxID.Text = "ID";
                textBoxID.ForeColor = Color.Gray;
            }
        }
        private void textFirstname_Enter(object sender, EventArgs e)
        {
            string fname = textFirstname.Text;
            if (fname.Equals("First name"))
            {
                textFirstname.Text = "";
                textFirstname.ForeColor = Color.Black;
            }
        }

        private void textFirstname_Leave(object sender, EventArgs e)
        {
            string fname = textFirstname.Text;
            if(fname.Equals("First name") || fname.Equals(""))
            {
                textFirstname.Text = "First name";
           textFirstname.ForeColor = Color.Gray;
            }
        }
        private void textLastname_TextChanged(object sender, EventArgs e)
        {

        }

        private void textLastname_Enter(object sender, EventArgs e)
        {
            string lname = textLastname.Text;
            if (lname.Equals("Last name"))
            {
                textLastname.Text = "";
                textLastname.ForeColor = Color.Black;
            }
        }

        private void textLastname_Leave(object sender, EventArgs e)
        {
            string lname = textLastname.Text;
            if (lname.Equals("Last name") || lname.Equals(""))
            {
                textLastname.Text = "Last name";
                textLastname.ForeColor = Color.Gray;
            }
        }

        private void textBoxEmail_Enter(object sender, EventArgs e)
        {
            string email = textBoxEmail.Text;
            if (email.Equals("Email Address"))
            {
                textBoxEmail.Text = "";
                textBoxEmail.ForeColor = Color.Black;
            }
        }

        private void textBoxEmail_Leave(object sender, EventArgs e)
        {
            string email = textBoxEmail.Text;
            if (email.Equals("Email Address") || email.Equals(""))
            {
                textBoxEmail.Text = "Email Address";
                textBoxEmail.ForeColor = Color.Gray;
            }
        }

        private void textBoxUsername_Enter(object sender, EventArgs e)
        {
            string usn = textBoxUsername.Text;
            if (usn.Equals("Username"))
            {
                textBoxUsername.Text = "";
                textBoxUsername.ForeColor = Color.Black;
            }
        }

        private void textBoxUsername_Leave(object sender, EventArgs e)
        {
            string usn = textBoxUsername.Text;
            if (usn.Equals("Username") || usn.Equals(""))
            {
                textBoxUsername.Text = "Username";
                textBoxUsername.ForeColor = Color.Gray;
            }
        }

        private void textBoxPassword_Enter(object sender, EventArgs e)
        {
            string pass = textBoxPassword.Text;
            if (pass.Equals("Password"))
            {
                textBoxPassword.Text = "";
                textBoxPassword.UseSystemPasswordChar = true;
                textBoxPassword.ForeColor = Color.Black;
            }
        }

        private void textBoxPassword_Leave(object sender, EventArgs e)
        {
            string pass = textBoxPassword.Text;
            if (pass.Equals("Password") || pass.Equals(""))
            {
                textBoxPassword.Text = "Password";
                textBoxPassword.UseSystemPasswordChar = false;
                textBoxPassword.ForeColor = Color.Gray;
            }
        }

        private void textBoxConfirmpass_Enter(object sender, EventArgs e)
        {
            string passC = textBoxConfirmpass.Text;
            if (passC.Equals("Confirm Password"))
            {
                textBoxConfirmpass.Text = "";
                textBoxConfirmpass.UseSystemPasswordChar = true;
                textBoxConfirmpass.ForeColor = Color.Black;
            }
        }

        private void textBoxConfirmpass_Leave(object sender, EventArgs e)
        {
            string passC = textBoxConfirmpass.Text;
            if (passC.Equals("Confirm Password") || passC.Equals(""))
            {
                textBoxConfirmpass.Text = "Confirm Password";
                textBoxConfirmpass.UseSystemPasswordChar = false;
                textBoxConfirmpass.ForeColor = Color.Gray;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Enter(object sender, EventArgs e)
        {
          
        }

        private void label2_Leave(object sender, EventArgs e)
        {
           
        }

        private void label2_MouseEnter(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Black;
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ForeColor = Color.White;
        }

        //to check if the username already exists
        public Boolean checkIDExist()
        { 
            DB db = new DB();
            string id = textBoxID.Text;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand("Select * FROM Student_Info WHERE Id= @id", db.GetConnection());

            command.Parameters.AddWithValue("@id", SqlDbType.VarChar).Value = id;
            
            adapter.SelectCommand = command;
            adapter.Fill(table);

            //check if this ID already exists in the database or not
            if(table.Rows.Count > 0) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Boolean checkTextBoxesValues()
        {
            string fname = textFirstname.Text;
            string lname = textLastname.Text;
            string email = textBoxEmail.Text;
            string uname = textBoxUsername.Text;
            string pass = textBoxPassword.Text;
            string passC = textBoxConfirmpass.Text;
            if(fname.Equals("First name") || lname.Equals("Last name") || email.Equals("Email Address")
                || uname.Equals("Username") || pass.Equals("Password") || passC.Equals("Confirm Password"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    
        //Create account button
        private void ButtonCreateaccount_Click(object sender, EventArgs e)
        {
            DB db = new DB();
           //Add new user
            SqlCommand command = new SqlCommand("INSERT INTO Student_Info(Id,FirstName,LastName,Email,Name,Password) VALUES (@id,@fname, @lname, @email, @usn, @pass)", db.GetConnection());

            command.Parameters.Add("@id", SqlDbType.Int).Value = textBoxID.Text;
            command.Parameters.Add("@fname", SqlDbType.VarChar).Value = textFirstname.Text;
            command.Parameters.Add("@lname", SqlDbType.VarChar).Value = textLastname.Text;
            command.Parameters.Add("@email", SqlDbType.VarChar).Value = textBoxEmail.Text;
            command.Parameters.Add("@usn", SqlDbType.VarChar).Value = textBoxUsername.Text;
            command.Parameters.Add("@pass", SqlDbType.VarChar).Value = textBoxPassword.Text;

            //open the connection
            db.OpenConnection();

            //checck if all the information are filled
            if(!checkTextBoxesValues())
            {
                //check if the password is equals to confirm passwrord
                if (textBoxPassword.Text.Equals(textBoxConfirmpass.Text))
                {
                    //checck if the ID already exist in the database
                    if (checkIDExist())
                    {
                        MessageBox.Show("This ID already exists. Kindly enter the correct one!","Duplicate ID",MessageBoxButtons.OKCancel,MessageBoxIcon.Error);
                    }
                    else
                    {
                        //execute the query
                        if (command.ExecuteNonQuery() == 1)
                        {
                            MessageBox.Show("Your Account Has been Created","Account",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Error!");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect Password confirmation.","Password Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please fill all the information.");
            }

            //to close the connection
            db.CloseConnection();
        }

        private void labelLogin_MouseEnter(object sender, EventArgs e)
        {
            labelLogin.ForeColor = Color.Yellow;
        }

        private void labelLogin_MouseLeave(object sender, EventArgs e)
        {
            labelLogin.ForeColor = Color.White;
        }

        private void labelLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainFrom login = new MainFrom();
            login.Show();
        }

        private void checkRegPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkRegPass.Checked)
            {
                textBoxPassword.UseSystemPasswordChar = false;
                var checkbox = (CheckBox)sender;
                checkbox.Text = "Hide Password";
            }
            else
            {
                textBoxPassword.UseSystemPasswordChar = true;
                var checkbox = (CheckBox)sender;
                checkbox.Text = "Show Password";
            }
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {
            DB db = new DB();
            db.OpenConnection();
            SqlDataAdapter da = new SqlDataAdapter("SELECT isnull(max(cast(Id as int)), 0)+1 FROM Student_Info", db.GetConnection());
            DataTable dt = new DataTable();
            da.Fill(dt);
            textBoxID.Text = dt.Rows[0][0].ToString();
            this.ActiveControl = textFirstname;
            db.CloseConnection();
        }
    }
}
