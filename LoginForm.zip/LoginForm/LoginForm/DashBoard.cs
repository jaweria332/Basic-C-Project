﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LoginForm
{
    public partial class DashBoard : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=E:\\C#\\LoginForm\\LoginForm\\LoginInfo.mdf;Integrated Security=True");
        public DashBoard()
        {
            InitializeComponent();
        }

        private void DashBoard_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }


        //to Retrieve information
        private void buttonSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            MessageBox.Show("Connected!");
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student_Info WHERE Id=" + int.Parse(textDashId.Text),con);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                textDashfname.Text = (dr["FirstName"].ToString());
                textDashlname.Text = (dr["LastName"].ToString());
                textDashEMail.Text = (dr["Email"].ToString());
                textDashpassword.Text = (dr["Password"].ToString());
            }
            con.Close();
            textDashId.ReadOnly = true;
            textDashId.Enabled = false;
        }

        //for logout button
        private void buttonLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainFrom form1 = new MainFrom();
            form1.Show();
        }


        //to update information
        private void buttonSave_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            string ID = textDashId.Text;
            string FN = textDashfname.Text;
            string LN = textDashlname.Text;
            string ML = textDashEMail.Text;
            string PASS = textDashpassword.Text;
            if(FN.Equals(""))
            {
                MessageBox.Show("Please enter your first name.", "Account Details", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if(LN.Equals(""))
            {
                MessageBox.Show("Please enter your last name.", "Account Details.",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if(ML.Equals(""))
            {
                MessageBox.Show("Please enter your Email address.", "Account Details.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (PASS.Equals(""))
            {
                MessageBox.Show("Please enter your password.", "Account Details.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //open the connection
                db.OpenConnection();

                //setting query
                string query = "UPDATE Student_Info SET FirstName='" +@FN + "', LastName='" +@LN + "',Email='" +@ML + "',Password='" +@PASS + "' WHERE Id= '" + textDashId.Text + "'";
                SqlCommand Updatecom = new SqlCommand(query, db.GetConnection());
                Updatecom.Parameters.Add("@FN",SqlDbType.VarChar).Value = textDashfname.Text;
                Updatecom.Parameters.Add("@LN",SqlDbType.VarChar).Value = textDashlname.Text;
                Updatecom.Parameters.Add("@ML",SqlDbType.VarChar).Value = textDashEMail.Text;
                Updatecom.Parameters.Add("@PASS", SqlDbType.VarChar).Value = textDashpassword.Text;

                //execute the query
                if (Updatecom.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Your Account Has been Updated", "Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error!", "Login Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                db.CloseConnection();
            }
            
        }

        private void checkBoxPass_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBoxPass.Checked)
            {
                textDashpassword.UseSystemPasswordChar = false;
                var checkbox = (CheckBox)sender;
                checkbox.Text = "Hide Password";
            }
            else
            {
                textDashpassword.UseSystemPasswordChar = true;
                var checkbox = (CheckBox)sender;
                checkbox.Text = "Show Password";
            }
        }
    }
}
