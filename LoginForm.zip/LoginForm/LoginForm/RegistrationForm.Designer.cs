﻿namespace LoginForm
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkRegPass = new System.Windows.Forms.CheckBox();
            this.labelLogin = new System.Windows.Forms.Label();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.ButtonCreateaccount = new System.Windows.Forms.Button();
            this.textBoxConfirmpass = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.textLastname = new System.Windows.Forms.TextBox();
            this.textFirstname = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(24)))), ((int)(((byte)(34)))));
            this.panel1.Controls.Add(this.checkRegPass);
            this.panel1.Controls.Add(this.labelLogin);
            this.panel1.Controls.Add(this.textBoxID);
            this.panel1.Controls.Add(this.ButtonCreateaccount);
            this.panel1.Controls.Add(this.textBoxConfirmpass);
            this.panel1.Controls.Add(this.textBoxEmail);
            this.panel1.Controls.Add(this.textBoxPassword);
            this.panel1.Controls.Add(this.textBoxUsername);
            this.panel1.Controls.Add(this.textLastname);
            this.panel1.Controls.Add(this.textFirstname);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(533, 509);
            this.panel1.TabIndex = 1;
            // 
            // checkRegPass
            // 
            this.checkRegPass.AutoSize = true;
            this.checkRegPass.ForeColor = System.Drawing.Color.White;
            this.checkRegPass.Location = new System.Drawing.Point(23, 372);
            this.checkRegPass.Name = "checkRegPass";
            this.checkRegPass.Size = new System.Drawing.Size(102, 17);
            this.checkRegPass.TabIndex = 203;
            this.checkRegPass.Text = "Show Password";
            this.checkRegPass.UseVisualStyleBackColor = true;
            this.checkRegPass.CheckedChanged += new System.EventHandler(this.checkRegPass_CheckedChanged);
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogin.ForeColor = System.Drawing.Color.White;
            this.labelLogin.Location = new System.Drawing.Point(154, 471);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(222, 20);
            this.labelLogin.TabIndex = 202;
            this.labelLogin.Text = "Already Have Account? Login!";
            this.labelLogin.Click += new System.EventHandler(this.labelLogin_Click);
            this.labelLogin.MouseEnter += new System.EventHandler(this.labelLogin_MouseEnter);
            this.labelLogin.MouseLeave += new System.EventHandler(this.labelLogin_MouseLeave);
            // 
            // textBoxID
            // 
            this.textBoxID.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxID.ForeColor = System.Drawing.Color.Gray;
            this.textBoxID.Location = new System.Drawing.Point(23, 94);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.ReadOnly = true;
            this.textBoxID.Size = new System.Drawing.Size(486, 29);
            this.textBoxID.TabIndex = 201;
            this.textBoxID.Text = "ID";
            this.textBoxID.Enter += new System.EventHandler(this.textBoxID_Enter);
            this.textBoxID.Leave += new System.EventHandler(this.textBoxID_Leave);
            // 
            // ButtonCreateaccount
            // 
            this.ButtonCreateaccount.BackColor = System.Drawing.Color.DarkOrange;
            this.ButtonCreateaccount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonCreateaccount.FlatAppearance.BorderSize = 0;
            this.ButtonCreateaccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonCreateaccount.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCreateaccount.ForeColor = System.Drawing.Color.Black;
            this.ButtonCreateaccount.Location = new System.Drawing.Point(23, 409);
            this.ButtonCreateaccount.Name = "ButtonCreateaccount";
            this.ButtonCreateaccount.Size = new System.Drawing.Size(486, 49);
            this.ButtonCreateaccount.TabIndex = 7;
            this.ButtonCreateaccount.Text = "Create Account";
            this.ButtonCreateaccount.UseVisualStyleBackColor = false;
            this.ButtonCreateaccount.Click += new System.EventHandler(this.ButtonCreateaccount_Click);
            // 
            // textBoxConfirmpass
            // 
            this.textBoxConfirmpass.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxConfirmpass.ForeColor = System.Drawing.Color.Gray;
            this.textBoxConfirmpass.Location = new System.Drawing.Point(23, 337);
            this.textBoxConfirmpass.Name = "textBoxConfirmpass";
            this.textBoxConfirmpass.Size = new System.Drawing.Size(486, 29);
            this.textBoxConfirmpass.TabIndex = 6;
            this.textBoxConfirmpass.Text = "Confirm Password";
            this.textBoxConfirmpass.Enter += new System.EventHandler(this.textBoxConfirmpass_Enter);
            this.textBoxConfirmpass.Leave += new System.EventHandler(this.textBoxConfirmpass_Leave);
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmail.ForeColor = System.Drawing.Color.Gray;
            this.textBoxEmail.Location = new System.Drawing.Point(23, 200);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(486, 29);
            this.textBoxEmail.TabIndex = 5;
            this.textBoxEmail.Text = "Email Address";
            this.textBoxEmail.Enter += new System.EventHandler(this.textBoxEmail_Enter);
            this.textBoxEmail.Leave += new System.EventHandler(this.textBoxEmail_Leave);
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPassword.ForeColor = System.Drawing.Color.Gray;
            this.textBoxPassword.Location = new System.Drawing.Point(23, 291);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(486, 29);
            this.textBoxPassword.TabIndex = 4;
            this.textBoxPassword.Text = "Password";
            this.textBoxPassword.Enter += new System.EventHandler(this.textBoxPassword_Enter);
            this.textBoxPassword.Leave += new System.EventHandler(this.textBoxPassword_Leave);
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUsername.ForeColor = System.Drawing.Color.Gray;
            this.textBoxUsername.Location = new System.Drawing.Point(23, 246);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(486, 29);
            this.textBoxUsername.TabIndex = 3;
            this.textBoxUsername.Text = "Username";
            this.textBoxUsername.Enter += new System.EventHandler(this.textBoxUsername_Enter);
            this.textBoxUsername.Leave += new System.EventHandler(this.textBoxUsername_Leave);
            // 
            // textLastname
            // 
            this.textLastname.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLastname.ForeColor = System.Drawing.Color.Gray;
            this.textLastname.Location = new System.Drawing.Point(274, 147);
            this.textLastname.Name = "textLastname";
            this.textLastname.Size = new System.Drawing.Size(235, 29);
            this.textLastname.TabIndex = 2;
            this.textLastname.Text = "Last name";
            this.textLastname.TextChanged += new System.EventHandler(this.textLastname_TextChanged);
            this.textLastname.Enter += new System.EventHandler(this.textLastname_Enter);
            this.textLastname.Leave += new System.EventHandler(this.textLastname_Leave);
            // 
            // textFirstname
            // 
            this.textFirstname.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFirstname.ForeColor = System.Drawing.Color.Gray;
            this.textFirstname.Location = new System.Drawing.Point(23, 147);
            this.textFirstname.Name = "textFirstname";
            this.textFirstname.Size = new System.Drawing.Size(235, 29);
            this.textFirstname.TabIndex = 200;
            this.textFirstname.Text = "First name";
            this.textFirstname.Click += new System.EventHandler(this.textFirstname_Click);
            this.textFirstname.Enter += new System.EventHandler(this.textFirstname_Enter);
            this.textFirstname.Leave += new System.EventHandler(this.textFirstname_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOrange;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(533, 81);
            this.panel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(510, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            this.label2.Enter += new System.EventHandler(this.label2_Enter);
            this.label2.Leave += new System.EventHandler(this.label2_Leave);
            this.label2.MouseEnter += new System.EventHandler(this.label2_MouseEnter);
            this.label2.MouseLeave += new System.EventHandler(this.label2_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(24)))), ((int)(((byte)(34)))));
            this.label1.Location = new System.Drawing.Point(69, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(398, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "STUDENT REGISTRATION";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 509);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegistrationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxConfirmpass;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.TextBox textLastname;
        private System.Windows.Forms.TextBox textFirstname;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonCreateaccount;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.CheckBox checkRegPass;
    }
}