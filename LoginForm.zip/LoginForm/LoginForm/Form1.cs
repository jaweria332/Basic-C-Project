﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LoginForm
{
    public partial class MainFrom : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=E:\\C#\\LoginForm\\LoginForm\\LoginInfo.mdf;Integrated Security=True");
        public MainFrom()
        {
            InitializeComponent();
            this.textPassword.AutoSize = false;
            this.textPassword.Size = new Size(this.textPassword.Size.Width, 26);
        }

        private void MainFrom_Load(object sender, EventArgs e)
        {

        }

        private void label2_MouseEnter(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Black;
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ForeColor = Color.White;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            string id = textUser.Text;
            string password = textPassword.Text;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand("Select * FROM Student_Info WHERE Id='"+textUser.Text+"' and Password='"+textPassword.Text+"'",db.GetConnection());

            command.Parameters.AddWithValue("@Id", SqlDbType.VarChar).Value = id;
            command.Parameters.AddWithValue("@Password", SqlDbType.VarChar).Value = password;
            
            adapter.SelectCommand = command;
            adapter.Fill(table);

            //check if user exists or not
            if(table.Rows.Count > 0) 
            {
                this.Hide();
                DashBoard dashboard = new DashBoard();
                dashboard.Show();
            }
            else
            {
                if(id.Equals(""))
                {
                    MessageBox.Show("Enter Your ID to Login", "Empty ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (password.Equals(""))
                {
                    MessageBox.Show("Enter Your Password to Login", "Empty Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Wrong ID or Password", "Wrong Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void labelSignup_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistrationForm registerform = new RegistrationForm();
            registerform.Show();
        }

        private void labelSignup_MouseEnter(object sender, EventArgs e)
        {
            labelSignup.ForeColor = Color.Yellow;
        }

        private void labelSignup_MouseLeave(object sender, EventArgs e)
        {
            labelSignup.ForeColor = Color.White;
        }

        private void textUser_Enter(object sender, EventArgs e)
        {
            string user = textUser.Text;
            if (user.Equals("Enter ID"))
            {
                textUser.Text = "";
                textUser.ForeColor = Color.Black;
            }
        }

        private void textUser_Leave(object sender, EventArgs e)
        {
            string user = textUser.Text;
            if (user.Equals("Enter ID") || user.Equals(""))
            {
                textUser.Text = "Enter ID";
                textUser.ForeColor = Color.Gray;
            }
        }

        private void textPassword_Enter(object sender, EventArgs e)
        {
            string pass = textPassword.Text;
            if (pass.Equals("Enter Password"))
            {
                textPassword.Text = "";
                textPassword.UseSystemPasswordChar = true;
                textPassword.ForeColor = Color.Black;
            }
        }

        private void textPassword_Leave(object sender, EventArgs e)
        {
            string pass = textPassword.Text;
            if (pass.Equals("Enter Password") || pass.Equals(""))
            {
                textPassword.Text = "Enter Password";
                textPassword.UseSystemPasswordChar = false;
                textPassword.ForeColor = Color.Gray;
            }
        }
    }
}
